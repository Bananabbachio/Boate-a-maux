// BoîteÀMots.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//

#include <iostream>
#include <fstream>
#include <string>
#include <Windows.h>
#include <list>

using namespace std;


fstream lesMots;
string mots;
list<string> Lsmots;
string selected;
list<int> allIndeks;
int indeks;
int LsmotsLEN = 0;

string get(list<string> ltoget,int index){
    int* indexx= new int;
   *indexx=0;
    for (string stoget : ltoget) {
        if (index == *indexx) {
            return stoget;
        }
       *indexx+= 1;
    }
}


int main()
{
    time_t temp = time(0);
    SetConsoleOutputCP(65001);
    lesMots.open("mots.txt");
    while (getline(lesMots, mots)) {
        std::cout << mots << endl;
        Lsmots.push_back(mots);
        LsmotsLEN++;
    }
    for (string moti : Lsmots) {
        std::cout << moti << endl;
    }
    while (!Lsmots.empty()) {
        system("cls");
        std::cout << endl;
        std::cout << "le mots est tiré:" << endl;
        indeks = (rand() + time(0)) % LsmotsLEN;
        allIndeks.push_back(indeks);
        selected = get(Lsmots, indeks);
        std::cout << selected << endl;
        Lsmots.remove(selected);
        LsmotsLEN--;
        if (!Lsmots.empty()) {
            system("pause");
        }
    }
    std::cout << " tu a tiré tous les mots, relance le programme dans le cmd pour recommencer";
}

// Exécuter le programme : Ctrl+F5 ou menu Déboguer > Exécuter sans débogage
// Déboguer le programme : F5 ou menu Déboguer > Démarrer le débogage

// Astuces pour bien démarrer : 
//   1. Utilisez la fenêtre Explorateur de solutions pour ajouter des fichiers et les gérer.
//   2. Utilisez la fenêtre Team Explorer pour vous connecter au contrôle de code source.
//   3. Utilisez la fenêtre Sortie pour voir la sortie de la génération et d'autres messages.
//   4. Utilisez la fenêtre Liste d'erreurs pour voir les erreurs.
//   5. Accédez à Projet > Ajouter un nouvel élément pour créer des fichiers de code, ou à Projet > Ajouter un élément existant pour ajouter des fichiers de code existants au projet.
//   6. Pour rouvrir ce projet plus tard, accédez à Fichier > Ouvrir > Projet et sélectionnez le fichier .sln.
